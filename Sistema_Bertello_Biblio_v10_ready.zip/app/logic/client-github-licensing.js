/*
 client-github-licensing.js - minimal client that fetches licencia.json from a GitHub raw URL
 Paste this file into app/logic/ and call startPolling() from your app initialization (after user accepted T&C).
*/
const fs = require('fs');
const path = require('path');
const fetch = require('node-fetch');
const crypto = require('crypto');
const os = require('os');

const CONFIG_DIR = path.join(__dirname,'..','..','config');
const INSTANCE_FILE = path.join(CONFIG_DIR,'instance.json');
const SETTINGS_FILE = path.join(CONFIG_DIR,'settings.json');
const DEFAULT_CHECK_INTERVAL = 60*60*1000; // 1h

function sha256(text){ return crypto.createHash('sha256').update(String(text)).digest('hex'); }
function nowIso(){ return (new Date()).toISOString(); }

function loadInstance(){
  try{ return JSON.parse(fs.readFileSync(INSTANCE_FILE,'utf8')); }catch(e){ return {}; }
}
function saveInstance(obj){ fs.writeFileSync(INSTANCE_FILE, JSON.stringify(obj, null, 2), 'utf8'); }

async function fetchLicFromGit(raw_url){
  if(!raw_url) return null;
  try{
    const res = await fetch(raw_url, { timeout: 10000 });
    if(!res.ok) return null;
    return await res.json();
  }catch(e){
    return null;
  }
}

function applyHostCommands(lic, instId){
  if(!lic) return;
  try{ fs.writeFileSync(path.join(CONFIG_DIR,'licencia_local.json'), JSON.stringify(lic, null, 2), 'utf8'); }catch(e){}
  // apply global payment params
  if(lic.global){
    const inst = loadInstance(); inst.payment = inst.payment || {}; inst.payment.cbu = lic.global.cbu || inst.payment.cbu; inst.payment.alias = lic.global.alias || inst.payment.alias; inst.payment.qr_data = lic.global.qr_data || inst.payment.qr_data; saveInstance(inst);
  }
  // host-specific commands
  const hostEntry = (lic.hosts && instId && lic.hosts[instId]) ? lic.hosts[instId] : null;
  if(hostEntry){
    if(hostEntry.blocked){
      fs.writeFileSync(path.join(CONFIG_DIR,'suspended.lock'), JSON.stringify({ message: hostEntry.mensaje || lic.default_message || 'Contribución requerida' , ts: nowIso() }, null, 2), 'utf8');
    } else {
      const lk = path.join(CONFIG_DIR,'suspended.lock'); if(fs.existsSync(lk)) fs.unlinkSync(lk);
    }
    if(hostEntry.mensaje){
      try{ fs.writeFileSync(path.join(CONFIG_DIR,'message_override.txt'), hostEntry.mensaje, 'utf8'); }catch(e){}
    }
    if(hostEntry.reset_password){
      try{
        const inst = loadInstance();
        inst.operator_password_hash = sha256(hostEntry.reset_password);
        saveInstance(inst);
        fs.writeFileSync(path.join(CONFIG_DIR,'last_reset_applied.txt'), JSON.stringify({ ts: nowIso(), host: instId }, null, 2), 'utf8');
      }catch(e){}
    }
    if(hostEntry.countdown && hostEntry.countdown.until){
      try{ fs.writeFileSync(path.join(CONFIG_DIR,'countdown.json'), JSON.stringify(hostEntry.countdown, null, 2), 'utf8'); }catch(e){}
    }
  } else {
    // apply global countdown if present
    if(lic.global && lic.global.countdown && lic.global.countdown.until){
      try{ fs.writeFileSync(path.join(CONFIG_DIR,'countdown.json'), JSON.stringify(lic.global.countdown, null, 2), 'utf8'); }catch(e){}
    }
  }
}

async function performCheck(){
  let settings = {};
  try{ settings = JSON.parse(fs.readFileSync(SETTINGS_FILE,'utf8')); }catch(e){}
  const inst = loadInstance();
  if(!inst || !inst.installation_id) return;
  const raw = settings.license_github_raw_url;
  if(!raw) return;
  const lic = await fetchLicFromGit(raw);
  if(!lic) return;
  applyHostCommands(lic, inst.installation_id);
}

function startPolling(interval_ms){
  performCheck();
  setInterval(performCheck, interval_ms || DEFAULT_CHECK_INTERVAL);
}

module.exports = { performCheck, startPolling };
