# 📚 Sistema Bertello Seba Biblio

**Sistema_Bertello_Seba_Biblio** es un software de gestión bibliotecaria multiplataforma.  
Incluye todas las funciones básicas para administrar libros, usuarios, préstamos y reservas, además de importación, exportación y notificaciones automáticas.  

## 🚀 Funciones principales
- CRUD de **Libros, Usuarios, Préstamos y Reservas**  
- **Importación/Exportación** de archivos CSV y MARC21  
- **Generación de etiquetas PDF** con código de barras (A4, dos columnas)  
- **Notificaciones automáticas** por correo (SMTP real)  
  - Ganchos listos para WhatsApp y Telegram  
- **Panel de configuración de notificaciones**  
- **Control remoto de licencias y contribuciones**  
  - Bloqueo/desbloqueo automático por archivo `licencia.json` en el repo remoto  
- Empaquetado automático en instaladores:  
  - `.exe` (Windows)  
  - `.AppImage` (Linux)  

---

## 🛠️ Modo técnico (desarrolladores)

### Prerrequisitos
- Node.js 18+  
- npm  
- PostgreSQL  

### Instalación
```bash
git clone https://github.com/TU_USUARIO/TU_REPO.git
cd TU_REPO
npm install
```

### Configuración
1. Edita `config/settings.json` con tus datos reales de PostgreSQL y SMTP.  
2. Crea la base de datos y corre migraciones Prisma:  
   ```bash
   npx prisma migrate deploy
   ```
3. Inicia el backend:
   ```bash
   npm run start
   ```
4. (Opcional) Inicia el frontend:
   ```bash
   cd src/ui
   npm run start
   ```

---

## 👩‍💻 Modo usuario final (no técnico)

No hace falta instalar nada manualmente.  
Simplemente:

1. Ve a la pestaña **[Releases](../../releases)** de este repositorio.  
2. Descarga el instalador correspondiente a tu sistema:  
   - **Windows** → `.exe`  
   - **Linux** → `.AppImage`  
3. Instálalo y abrí el programa.  

⚡ La licencia se valida automáticamente al iniciar, y el sistema queda listo para usar.  

---

## 🔬 Pruebas automáticas
Corre pruebas de backend y frontend:  
```bash
npm test
```

Incluyen:
- Validación de CRUD  
- Importación de CSV/MARC21  
- Notificaciones simuladas  
- Control de licencias  

---

## 📄 Licencia y Contribuciones
Este proyecto cuenta con un **sistema de control remoto de licencias**:  
- El archivo `licencia.json` se sincroniza automáticamente desde el repositorio remoto.  
- Las instalaciones locales se bloquean/desbloquean según la licencia central.  

Contribuciones son bienvenidas mediante **Pull Requests**.  

---

## 🌟 Créditos
Sistema desarrollado como **proyecto de gestión bibliotecaria**, integrando backend, frontend, notificaciones y empaquetado multiplataforma.
