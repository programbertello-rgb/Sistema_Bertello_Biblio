Sistema_Bertello_Biblio - Paquete V9 (Control via GitHub)

Contenido importante en este ZIP:
- config/settings.json  (poner la URL raw de licencia.json en license_github_raw_url)
- config/messages.json
- CONTRIBUCIONES.txt
- licencia.json (ejemplo; alojar este archivo en tu GitHub y actualizar según control)
- app/logic/client-github-licensing.js  (cliente que consulta licencia.json y aplica comandos)
- app/ui/contribuciones.html (pantalla de primer arranque para email + institución + aceptar T&C)

Cómo usar (resumen):
1. Subí el archivo 'licencia.json' a tu repo GitHub y copiá la URL 'raw' en config/settings.json -> license_github_raw_url.
2. En cada instalación, el primer usuario debe completar Email + Institución y aceptar T&C (usa contribuciones.html) - esto genera installation_id.
3. Desde tu repo en GitHub editá 'licencia.json' para bloquear/desbloquear instalaciones, resetear contraseña o activar cuenta regresiva.
4. Las copias instaladas consultan el archivo y aplican la instrucción automáticamente (en el próximo poll).

Ejemplo 'hosts' entry in licencia.json:
{
  "inst-abc123": {
    "blocked": true,
    "mensaje": "Su copia está bloqueada. Enviá comprobante a programbertello@gmail.com",
    "reset_password": null,
    "countdown": { "until": "2025-10-14T12:00:00Z", "action": "permitir_pareja" }
  }
}

Notas de seguridad:
- Si usás un repo público, cualquiera puede ver licencia.json. Para mayor privacidad, usá repo privado.
- Si usás repo privado, necesitarás implementar autenticación para que los clientes descarguen el raw JSON (no incluido en esta versión).
- Comunicá claramente en la UI la política de bloqueo y la obligación de aceptar T&C.

CVU incluido: 0000085700202514176457 (alias: seba.bertello)

